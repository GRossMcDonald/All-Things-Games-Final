import { useEffect } from "react";
import { checkAndUpdatePrices } from "./CheckPrices";

function WishlistPriceUpdater() {
  useEffect(() => {
    checkAndUpdatePrices();
  }, []);
}

export default WishlistPriceUpdater;
