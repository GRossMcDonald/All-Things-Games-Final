import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "./Wishlist.css";
import PopularGamesImg from "./PopularGamesImg";
import RemoveWishlistedGame from "./RemoveWishlistedGame";
import { fetchLoggedInUsersWishlistedGames } from "./LoggedInUserData";

const Wishlist = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen((isOpen) => !isOpen);
  };

  const loggedInEmail = useState(localStorage.getItem("loggedInEmail"));
  const [usersWishlistedGames, setUsersWishlistedGames] = useState([]);

  async function getUsersGames() {
    setUsersWishlistedGames(await fetchLoggedInUsersWishlistedGames());
  }

  useEffect(() => {
    getUsersGames();
  }, [usersWishlistedGames]);

  return (
    <div className="wishlist-games">
      <div className={`wishlist-container ${isOpen ? "is-open" : ""}`}>
        <ul className="wishlist">
          <p className="wishlist-title">{loggedInEmail}'s Wishlist</p>
          {usersWishlistedGames.map((game) => (
            <li key={game.itadId}>
              <Link to={`/GameInfoPage/${game.itadId}`}>
                <PopularGamesImg game={game} />
                <h4>{game.title}</h4>
              </Link>
              <RemoveWishlistedGame gameToRemove={game} />
            </li>
          ))}
        </ul>
      </div>
      <div
        className={`hamburger no-user-select ${isOpen ? "active" : ""}`}
        onClick={toggleMenu}
      >
        <span className="bar"></span>
        <span className="bar"></span>
      </div>
    </div>
  );
};

export default Wishlist;
